---
Title: "How to get started with Obsidian Dataview and DataviewJS"
URL: https://medium.com/os-techblog/how-to-get-started-with-obsidian-dataview-and-dataviewjs-5d6b5733d4a4
Pocket URL: https://getpocket.com/read/3448212461
Tags: [pocket, obsidian]
Excerpt: >
    If you haven’t read Obsession with Obsidian I can highly recommend it as a great introduction to Obsidian. To try out these examples and tips you will need to download and install Obsidian and then install the Dataview plugin, both of which are free.
---
# Dataview

![image](https://miro.medium.com/max/1600/1*cgsrcUaUKXAxk4pMhNpoVw.png)


 # Resources
 - [Getting started with Dataview 👓](https://medium.com/os-techblog/how-to-get-started-with-obsidian-dataview-and-dataviewjs-5d6b5733d4a4)
 - [Dataview Documentation 📄](https://blacksmithgu.github.io/obsidian-dataview/)
 - [How to get started with Obsidian Dataview and DataviewJS | by Jacqui Read | OS TechBlog | Medium](https://medium.com/os-techblog/how-to-get-started-with-obsidian-dataview-and-dataviewjs-5d6b5733d4a4)
 - [Article about replicating Notion's tables in Obsidian](https://input.sh/replicating-notions-tables-with-obsidian-plugins/)
 - [**My Obsidian Daily Note Template 2022 | by Michelle Mac | Medium**](https://mishacreatrix.medium.com/my-obsidian-daily-note-template-2022-b162a28302be)

Great article about #dataview ⬇️
> If you haven’t read [Obsession with Obsidian](https://medium.com/os-techblog/obsession-with-obsidian-320ff8a05570) I can highly recommend it as a great introduction to Obsidian.

- [ ] Learning to use it for self-generating #moc based on tags, which can be placed in frontmatter or in the body of the note. - ref [[Where to put tags in Dataview? YAML or BODY? - Help - Obsidian Forum]]

