# I'm Starting a Website!

up:: [[Blogging Ideas]]
tags:: #blog 


As the title says, I'm creating a website. No, it's not for a new business, but rather a place to host my resume, projects I'm currently working on, and as a dashboard to other related platforms, such as Notion, Obsidian Digital Garden, and more.

## Why?
So why build a website now? Why do it at all?
Well, I'm currently looking for a new job, and with that comes a lot of tasks:
- updated resume (and tailored to each specific job listing)
- updated LinkedIn Profile
- finally get around to posting code snippets on GitHub (and actually using git)
- online portfolio (this website itself)
- the actual job search!

## Showcasing "Jon"
I've just returned from a trip back east to visit family, and upon my return, the pressures of real life began to mount: work, house maintenance, all those Notion databases I've been meaning 
to build and share.... But the single largest task on my mind has been **Getting a new job**. While cooking dinner last night, I indulged my habit of perusing new YouTube videos from my favorite creators, and lo and behold, trusty [Network Chuck posted a video](https://www.youtube.com/watch?v=e2h_BreIxaQ&t=2002s) about getting a job in tech. It's not the first one he's done about this subject, but he had *just* posted it hours before I viewed it. I took it as a sign.



[HACK your way into a job (no experience required) - YouTube](https://www.youtube.com/watch?v=e2h_BreIxaQ&t=2002s)



Chuck explains the importance of building an online presence to showcase who you really are, since a resume is just a way to get past HR and A.I. screening software. You can hardly present the real 'you' in a resume, so having a website is a place to stretch one's legs.

Since I don't use social media, and I'm a bit of an introvert, it's always been difficult for me to keep up with putting myself out there, or even just hosting a profile online. My LinkedIn is pretty devoid of anything interesting. However, with my desire to push my career forward, I must take the necessary step of promoting myself, even just passively with a website. 

## Do all the things...*NOW!*

Of course, in my typical fashion, I've already noted all the other things I MUST do:
- start a newsletter with [Substack](https://substack.com/for-bloggers)
- begin a blog on my site and also post on [Medium](https://medium.com/) for increased exposure
- cross-post select entries to Reddit to engage with my community there
- post on [LinkedIn](https://www.linkedin.com/in/jddeleon/) and [Twitter](https://twitter.com/jondeleontech) frequently
- create YouTube walk-throughs for all my projects
- *you get the idea*


## Actually, just slow down
I'm trying to take this one step at a time. So today I purchased web hosting through [Hostinger](https://www.hostinger.com/), and I setup my new domain name: **[jdeleontech.com](https://jdeleontech.com)**. I'm going to setup my email next, followed by a simple Wordpress site to get a static downloadable version of my resume online, as well as a bio and a couple projects.

As in all aspects of life and work, I need to remind myself to breathe and take it slow. It's all a journey, and that's the point.




